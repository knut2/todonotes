#~ puts %x{call gem environment gemdir}
#~ exit
#
#Build rake4latex-gem
#
require 'knut_tools/rake/gempackager'
$:.unshift('lib')
require 'todo_gem'

$todo_gem_version = "0.1.1"  #ruby 1.9

#http://docs.rubygems.org/read/chapter/20
rake4latexgem = Gem_packer.new('todo_gem', $todo_gem_version){ |gemdef, s|
  s.name = "todo_gem"
  #major.minor.build  - see http://docs.rubygems.org/read/chapter/7
  s.version =  $todo_gem_version
  #~ s.author = "Knut Lickert"
  #~ s.email = "knut@lickert.net"
  #~ s.homepage = "http://ruby.lickert.net/todo_gem"
  #~ s.homepage = "http://gems.rubypla.net/"
  #~ s.rubyforge_project = 'todo_gem'
  s.platform = Gem::Platform::RUBY
  s.summary = "Build todo_gem-Files."
  s.description = <<DESCR
todo_gem.

Gem based on a proposal in http://forum.ruby-portal.de/viewtopic.php?f=11&t=11957
DESCR
  #~ s.files = Dir.glob("**/*").reject { |f|
    #~ f =~ /~$/ || f =~ /\.gem/ || f =~ /CVS/
  #~ }
  #~ s.require_path = "lib"
  s.require_path = "lib"
  s.files = %w{
lib/todo_gem.rb
examples/todo_how_to.rb
examples/todo_prim.rb
}
  #~ s.test_files    = %w{
#~ unittest/unittest_todo_gem.rb
#~ }
  #~ s.test_files   << Dir['unittest/expected/*']
  #~ s.test_files.flatten!

  #~ s.bindir = "bin"
  #~ s.executables << 'todo_gem.exe'

  s.has_rdoc	= true  
  #~ s.add_development_dependency('more_unit_test', '> 0.0.2')  #assert_equal_filecontent
  s.add_dependency('log4r') 
  #~ s.requirements << 'Optional: A (La)TeX-system if used as TeX-generator (in fact, you can create TeX-Files, but without a TeX-System you will have no fun with it ;-))'

  gemdef.public = true
  #~ gemdef.add_ftp_connection('ftp.rubypla.net', Knut::FTP_RUBYPLANET_USER, Knut::FTP_RUBYPLANET_PW, "/Ruby/gemdocs/todo_gem/#{$todo_gem_version}")


  #~ gemdef.define_test( 'unittest', FileList['unittest*.rb'])
  gemdef.versions << Todo::VERSION

}


desc "Default: :readme, :gem"
task :default => :check
#~ task :default => :test
#~ task :default => :readme
task :default => [ :gem ]
#~ task :default => :install
#~ task :default => :exe
#~ task :default => :copy
#~ task :default => :links
#~ task :default => :push



if $0 == __FILE__
  app = Rake.application
  app[:default].invoke
    #~ app[:test].invoke
  #~ app[:change_rakefiles].invoke
end


__END__
=Changes
0.1.0: Initial version
0.1.1: + todo2_gem
