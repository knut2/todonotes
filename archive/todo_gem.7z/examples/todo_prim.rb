$:.unshift('../lib')
require 'todo_gem'

#
#Hier Definition, wie oft.
#
Todo.instance.logger.level = Log4r::WARN
#~ Todo.instance.logger.level = Log4r::INFO


summe = 0
for i in 1..100 
        prim = nil
        to do 
                "Berechnen ob Primzahl, prim = true, ja, sonst nein"
        end
        print "Zahl #{i} ist "
        print "k" unless prim
        puts "eine Primzahl"
        summe += 1 if prim
end

todo "Summe am Ende der Schleife ausgeben"

#~ puts "\nDetailanalyse"
#~ print_stats(true)

