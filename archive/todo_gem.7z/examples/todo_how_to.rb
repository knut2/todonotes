$:.unshift('../lib')
require 'todo_gem'


to do 
  "mein Text"
end

todo "mein Text"

todo { "mein Text" }

todo ('mein Text' ) { "mein Text" }

todo do
  "mein Text"
end

print_stats
