=begin rdoc
Define todo-commands.

Gem based on a proposal in http://forum.ruby-portal.de/viewtopic.php?f=11&t=11957

=end

require 'singleton'
require 'log4r'

=begin rdoc
Container for todos.
=end
class Todo
  VERSION = '0.1.1'
  include Singleton
=begin rdoc
Define the singleton-instance.
=end
  def initialize()
    # @codeline is a Hash with Filename and codeline (key). Value is the number of calls.
    @codeline = {}
    @output = :always
    @logger = Log4r::Logger.new('TODO')
    @logger.outputters = Log4r::StdoutOutputter.new('TODO', :level => Log4r::ALL )
  end
  #Get logger to define alternative outputters...
  attr_reader :logger
  
=begin rdoc
Add a todo.

caller_pos contains the offset for caller()
=end
  def log( caller_pos, text )
    key = caller[caller_pos].split(':in').first

    if @codeline[key] #Codingzeile bereits gemeldet?
      @logger.info("#{key}(#{@codeline[key]+1}) #{text}")
    else  #Erste auftauchen
      @logger.warn("#{key} #{text}")
    end
    
    @codeline[key] ||= 0
    @codeline[key] += 1
  end
=begin rdoc
=end
  def add ( *args, &block )
    unless args.empty?
      args.each do |arg|
        #skip 4 levels of caller
        log 4, arg
      end
    end
    if block_given?
      log 2, yield
    end    
  end
  
=begin rdoc
=end
  def print_stats( )
    @codeline.each do |key, messages|
      puts( "todo in %s: %4i calls" % [ key, messages ] )
    end
  end
end

=begin rdoc
Define todo-commands to global usage.
=end
module Kernel
=begin rdoc
Usage:
  to do 
    "my todo-message"
  end
=end
  def to(*args,&block)
    Todo.instance.add(*args, &block)
  end
=begin rdoc
Usage 1:
  todo "my todo-message""

Usage 2:
  todo { "my todo-message" }

Usage 3:
  todo (:a) { "mein Text 2" }

Usage 4:
  todo do
    "my todo-message"
  end
=end
  alias :todo :to
=begin rdoc

=end
  def print_stats()
    Todo.instance.print_stats()
  end
end